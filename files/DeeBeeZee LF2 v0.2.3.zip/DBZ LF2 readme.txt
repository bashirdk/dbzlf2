===============================================================================
                     Dragon Ball Z Little Fighter 2 beta v0.2.3
                                  	28 May 2015

                             	   by bashscrazy
    
	Website: 	http://bashirdk.github.io/dbzlf2/ 
	Blog: 		http://dbzlf2.blogspot.ca/
	YouTube: 	http://dbzlf2.blogspot.ca/
	Forum: 		http://dbzlf2.userboard.net 
   
===============================================================================

CHANGELOG v0.2.3

-4 New Characters
	-Gohan (Buu)		-Level 4
	-SS Gohan (Buu)		-Level 5
	-SS2 Gohan (Buu)	-Level 6
	-Ultimate Gohan		-Level 7
-New Face pics: now using anime pictures and shows level, attack and defense indicator
-Re-added ads to EXE but they are all related to the DBZ LF2 links and less visually obtrusive
-Modified EXE art

(minor changes)
-Common melee attacks now use state 7 in the itr frames. So basically while you are attacking you are also defending to create a small type of �clash�
-Jump recovery (flips) now DRAIN ki 
-AI improvements to all characters, mostly on CRAZY! Mode only though
- Goku and Vegeta can now fuse into Vegito using potara earrings, 50% chance Goku takes control and 50% Vegeta takes control, +500 health 

Major changes to Vegeta(Namek)
-Broke down Dirty Fireworks into D^A A (allows for new combos)
-Broke down Genocide Breaker into D^J A (in case kick is blocked no need to fly attacking nothing)
-Final Crash has been sped up significantly
-Final Burst Canon has been sped up a bit
_______________________________________________________________________________


CHANGELOG v0.1.7

-5 New Characters
	-Vegeta (Namek)		-Level 2
	-Goku (Buu)		-Level 4
	-SS Goku (Buu)		-Level 5
	-SS2 Goku (Buu)		-Level 6
-SS3 Goku (Buu)	-Level 7
-New Defense Levels (Updated all defense modifiers by 1.5x)
	-Level 1 = 1.0x attack and 1.5x defense
	-Level 2 = 1.1x attack and 1.65x defense
	-Level 3 = 1.3x attack and 1.95x defense
	-Level 4 = 1.6x attack and 2.4x defense
	-Level 5 = 2.0x attack and 3.0x defense
	-Level 6 = 2.5x attack and 3.75x defense
	-Level 7 = 3.1x attack and 4.65x defense
	-Level 8 = 3.8x attack and 5.7x defense
	-Level 9 = 5.0x attack and 7.5x defense
-Modified EXE art

(minor changes)
-Changed Hunter�s arrow to a level 1 ki blast
-Changed Ice (frozen) effect to blind effect (still in beta as you become temporarily invincible)
-Instant Transmission now teleports you to opposite side of where it usually puts you. (So if you and your opponent are facing each other, instead of continuing to face them, you will teleport behind them)
-Created a shitty recolour of the Cliff background to try and make my own wastelands hah
-Decreased the size of Super Vegito�s Kamehameha ball by 25%
-Added sound effect when you deflect a ki blast
-SS Vegeta (Android), Super Vegeta(Android) and SS2 Vegeta (Buu) use Big Bang Attack a bit faster with new voice clip!
-minor speed increase on Majin Vegeta�s Final Impact and it no longer disappears after a second (unless of course it�s destroyed)
-Fixed all of Vegeta�s bpoints (blood)

_______________________________________________________________________________

CHANGELOG v0.1.3

-4 New Characters
	-Vegeta (Android)	-Level 3
	-SS Vegeta (Android)	-Level 4
	-Super Vegeta		-Level 4? (1.8x attack, 1.6x defense)
	-Majin Vegeta		-Level 6
-New Level
	-Level 3 = 1.3x attack and defense modifier
-Compressed some of the BMP files making the extracted game much smaller
	(side effect includes some loss of quality in SOME of the sprites, but is hardly noticeable at all, 
	Especially in the heat of battle)
-Modified EXE art
-Modified SS Vegeta (Buu)�s Hellzone Grenade (originally shot 6 ground balls, now shoots 7 ground and 3 sky)
-Re-applied combos to the Vegeta (Buu) characters

(SIDE ADDITIONS)
-Fixed Vegito and Super Vegito�s Explosive wave hitboxes and adjusted damage.
-Added random �spectactor� in so you can watch the AI battle it out in VS mode.
-Re-added Bandit and Hunter so there is like a �stage� mode kind of (except their health is same so really easy to kill with higher level chars)
-Added my old Krillin character for some more variety. Haven�t edited the character but added some AI and 1.2 armor defense
_______________________________________________________________________________

CHANGELOG v0.1

-5 New characters
	-Vegeta (Buu)		-Level 4
	-SS Vegeta (Buu)	-Level 5
	-SS2 Vegeta (Buu)	-Level 6
	-Vegito			-Level 8
	-Super Vegito		-Level 9
-Implemented Level System
	-Level 4 = 1.6x attack and defense modifier
	-Level 5 = 2.0x attack and defense modifier
	-Level 6 = 2.5x attack and defense modifier
	-Level 8 = 3.8x attack and defense modifier
	-Level 9 = 5.0x attack and defense modififer
-Each character has AI at all 4 different difficulty settings

_______________________________________________________________________________

-------------
SPECIAL MOVES
-------------

('D' means Defend button, 'A' means Attack button, 'J' means Jump button)
('>', '^', 'v' means the direction buttons)
You can setup the Key Configuration by choosing "Control Settings" in the
main menu. But my setup is superior.


==ALL CHARACTERS==

1. Ki Blast
   D > A ( + A + A...)
2. Charge Ki
   D J A ( + A + A...)
3. Counter Attack
   Attack when being hit during Defend frames (D A)
   (Vegeta must be within close proximity of opponent)
   (Vegito can use it whenever as he uses instant transmission to get straight to opponent)


==Vegeta (Namek)==

1. Super Energy Wave Volley
   D > AJ
2. Dirty Fireworks
   D ^ A A
3. Genocide Breaker
   D ^ JA
4. Final Crash
   D > J
5. Final Burst Cannon
   D v J
6. Final Galick Cannon
   Grabbing Enemy + D ^ A
7. Basic Combo
   Super Punch + J
8. Dirty Fireworks Combo
   Super Punch + J + A
9. Final Burst Fireworks
   D ^ A, D v J
10. Final Burst Fireworks Combo
   Super Punch + J + A + D v J
11. Super Awesome Ultimate Combo
   Grabbing Enemy + D ^ A, D ^ J, D ^ A, D v J


==Vegeta (Android)==

1. Super Energy Wave Volley
   D > AJ
2. Maximum Flasher
   D > J
3. Super Saiyan
   D J AJ


==SS Vegeta (Android)==

1. Super Energy Wave Volley
   D > AJ
2. Final Flash
   D > J
3. Photon Bomber
   D ^ A
4. Maximum Flasher
   D ^ J
5. Big Bang Attack
   D v A
6. Combo Attack
   D v J
7. Amazing Impact Counter Attack
   D J
8. Amazing Impact Combo
   Super Punch, J
9. Amazing Impact Extended Combo
   Super Punch, J A
10. Big Bang Attack Combo
   Super Punch, J A, D v A
11. Ascended Super Saiyan (SUPER VEGETA!)
   D J AJ


==Super Vegeta (Android)==

1. Super Energy Wave Volley
   D > AJ
2. Final Flash
   D > J
3. Atomic Blast
   D ^ A
4. Big Bang Attack
   D v A
5. Counter Combo Attack
   D J
6. Basic  Combo
   Super Punch + J
7. Saiyan Energy Attack
  Basic Combo + DvA
8. Final Flash (Ultimate)
   Basic Combo + D^J
9. Atomic Energy Blast
   Atomic Blast + J + DvA
10. Atomic Final Flash
   Atomic Blast + J + D^J
11. Special Counter Attack
   Defend an attack + J
12. Super Special Counter Attacks
   After using Special Counter Attack you can press attack for finisher or link a Saiyan Energy Attack or a Final Flash
13. Base Form
  DJA D


==Vegeta (Buu)==

1. Super Energy Wave Volley
   D > AJ
2. Explosive Ki Blast
   D > AD 
3. Double Galick Cannon
   D v J
   Can also be used when catching opponent
4. Explosive Wave 
   D ^ J
   Can also be used as a counter attack by pressing Jump after defending a hit
5. Super Saiyan
   D J AJ
6. Babadi�s Mind Control
   D J AD 


==SS Vegeta (Buu)==

1. Super Energy Wave Volley
   D > AJ
2. Hellzone Grenade
   D > J
3. Final Burst Cannon
   D v J
4. Super Saiyan 2
   D J AJ
5. Base form
   D J AD


==SS2 Vegeta (Buu)==

1. Super Energy Wave Volley
   D > AJ
2. Big Bang Attack
   D v A
3. Infinite Break
   D v J
   Can also be used when catching opponent
4. Base Form
   D J AD


==Majin Vegeta== 

1. Super Energy Wave Volley
   D > AJ
2. Final Flash
   D > J
3. Big Bang Attack
   D v A
4. Final Impact
   D v J
5. Final Burst Cannon
   D ^ A
6. Final Explosion (ULTIMATE)
   D ^ J


==Goku (Buu)== 

1. Destructo Disk
   D ^ A
2. Kamehameha
   D > J
3. Solar Flare
   D v A
4. Instant Transmission (Enemy) 
   D v J
5. Instant Transmission (Ally)
   D v JJ
6. Basic Combo
   Super Punch + J
7. Spirit Bomb
   Super Punch + J, D ^ J
8. Super Saiyan
   D J AJ


==SS Goku (Buu)== 

1. Super Energy Wave Volley
   D > AJ
2. Upwards Flash Kick
   D ^ A
3. Downwards Flash Kick
   D v A
4. Kamehameha
   D > J
5. Instant Transmission Kamehameha
   D > J, D > A
6. Super Kamehameha
   D > JA
7. Instant Transmission Super Kamehameha
   D > JA, D > A
8. Instant Transmission (Enemy) 
   D v J
9. Instant Transmission (Ally)
   D v JJ
10. Basic Combo
   Super Punch + J + A
11. Flash Kick Combo
   D ^ A + J + A
12. Double Flash Kick
   D ^ A, D v A
13. Super Saiyan 2
   D J AJ
14. Base Form
   D J AD


==SS2 Goku (Buu)== 

1. Super Energy Wave Volley
   D > AJ
2. Kamehameha
   D > J
3. Instant Transmission Kamehameha
   D > J, D > A
4. Super Kamehameha
   D > JA
5. Instant Transmission Super Kamehameha
   D > JA, D > A
6. Meteor Burst
   D v A, D > J, D ^ J
7. Explosive Wave
   D ^ J (can also be used when you are being grabbed as an escape maneuver)
8. Instant Transmission (Enemy) 
   D v J
9. Instant Transmission (Ally)
   D v JJ
10. Basic Combo
   Super Punch + J + A + A
11. Super Saiyan 3
   D J AJ
12. Base Form
   D J AD


==SS3 Goku (Buu)== 

1. Super Energy Wave Volley
   D > AJ
2. Kamehameha
   D > J
3. Instant Transmission Kamehameha
   D > J, D > A
4. Super Kamehameha
   D > JA
5. Instant Transmission Super Kamehameha
   D > JA, D > A
6. Kiai Blast Combo
   D ^ A A A A
7. Explosive Wave
   D ^ J (can also be used when you are being grabbed as an escape maneuver)
8. Instant Transmission (Enemy) 
   D v J
9. Instant Transmission (Ally)
   D v JJ
10. Instant Transmission Attack
   D v J + A
11. Basic Combo
   Super Punch + J + A
12. Basic Combo + Kamehameha Finish
   Super Punch + J + A + J
13. Base Form
   D J AD


==Gohan (Buu)== 

1. Kamehameha
   D > J
2. Explosive Wave
   D ^ J
3. Basic Combo
   Super Punch + J
4. Super Saiyan
   D J AJ
5. Ultimate Gohan
D J AD


==SS Gohan (Buu)== 

1. Kamehameha
   D > J
2. Super Kamehameha
  D > JA 
3. Double Homing Blast
  D ^ A
4. Explosive Combination
  D ^ J A
  Can also be used when catching opponent
5. Super Saiyan 2
   D J AJ
6. Base Form
   D J AD

==SS2 Gohan (Buu)== 

1. Super Energy Wave Volley
   D > AJ
2. Electric Kamehameha
   D > J
3. Super Electric Kamehameha
   D > JA
4. Rush Attack
   D ^ A A J
5. Rush Attack Dodge
  D ^ A J
  Can move up or down on z axis to dodge while rushing forwards
6. Rush Attack Counter
  D ^ A AJ
7. Base Form
   D J AD


==Ultimate Gohan (Buu)== 

1. Electric Kamehameha
   D > J
2. Reflective Shield
   D ^ J
3. Ultimate Knuckle
   D v A
4. Ultimate Knuckle Combo
  D v A J
5. Ultimate Combo
  D v A J J


==Vegito==

1. Kamehameha
   D > J A
2. Super Kamehameha
   D > J
3. Instant Transmission Kamehameha
   D > J J (or D > J, D > A to change directions)
4. Instant Transmission Enemy
   D v J
5. Instant Transmission Ally
   D v JJ
6. Big Bang Attack
   D v A
7. Ki Cannon
   D ^ A
8. Twin Dragon Shot
   D ^ AA
9. Explosive Wave
   D ^ J
10. Super Vegito
    D J AJ
11. Combo
    Super Punch + J
12. Volley Combo
    Super Punch + J A A A


==Super Vegito==

1. Banshee Blast
   D > AJ
2. Kamehameha
   D > J
3. Final Kamehameha
   D v J
4. Big Bang Attack
   D V A
5. Spirit Sword
   D ^ A
6. Explosive Wave
   D ^ J
   Dance of Pain + D J A
7. Tele Ki Blast
   Rowing + J

COMBOS

Confusing.. Might as well find them for yourself.

COMBOS
- Combo 1 (head kicks)				Before Super Punch Lands Press Jump (AJ)
- Cancel Combo 1				Before the flip kick lands press D - (precision is key - spamming doesn't work)
- Combo 2 (sweep and up kick)		        	Combo 1 + Jump
- Combo 3 (sweep and up kick)		        	Super Punch + Jump
- Combo 4 (Punch Smash)		        	Combo 2 &/or 3 + Attack
- Combo 5 (Kick Up)		        		Super Punch + Attack
- Combo 6 (Punch Smash)		        	Super Punch + Attack + Jump
- Combo 7 (					Super Punch + Attack + Attack
- Combo 8 (Elbow + Knee Neck Snapper)		Combo 7 + Attack
- COmbo 9 (Finisher)				Combo 8 + Attack
- Combo 10 (Sweep Finisher)		        	Combo 2/3 + Jump + Combo 9
- Combo 11 (Kame Finish)			Combo 5 + D>J 
- Combo 12 (Big Bang Finish)			Combo 5 + DVA 
- Combo 12 (Spirit Sword Finish)			Combo 5 + D^A 


------------------------------------------------------------------------------------
CREDITS
------------------------------------------------------------------------------------
- Special Thanks to Harlequin for improving my spriting ability
- prince_freeza for the aura
- matt4300 for the big bang start up and dash attack base
- hell fightter for the "power dust" 
- Various DBZ video games for some of the sprites
- A-Man for helping with HEX editing (armor)
- BardockSonic from DeviantArt for his DBZ drawings used in EXE
- VICDBZ from DeviantArt for his DBZ Drawings used in EXE
- RayzorBlade189 from DeviantArt for his DBZ Drawings used in EXE
- Harlequin for SS Goku Hair


------------------------------------------------------------------------------------
End Notes
------------------------------------------------------------------------------------

Possible changes in future update

-Add new characters: 
	- Future Trunks (Armor)	
	- SS Future Trunks (Armor)
	- Ultra Future Trunks (Armor)		
-Make improvements to AI

